# OrçaElétrica — Android V4
Base Android do OrçaElétrica V4 com geração/compartilhamento de PDF via Android.
