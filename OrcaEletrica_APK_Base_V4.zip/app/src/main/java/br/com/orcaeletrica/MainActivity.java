package br.com.orcaeletrica;

import android.app.*;import android.os.*;import android.print.*;import android.webkit.*;import android.content.*;import android.net.Uri;import android.graphics.pdf.PdfDocument;import java.io.*;import androidx.core.content.FileProvider;

public class MainActivity extends Activity {
 WebView web; File pdfFile;
 @Override public void onCreate(Bundle b){super.onCreate(b); web=new WebView(this); web.getSettings().setJavaScriptEnabled(true); web.getSettings().setDomStorageEnabled(true); web.addJavascriptInterface(new Bridge(),"Android"); web.loadUrl("file:///android_asset/index.html"); setContentView(web);}
 class Bridge { @JavascriptInterface public void generatePdf(){runOnUiThread(()->createPdf(false));} @JavascriptInterface public void sharePdf(){runOnUiThread(()->createPdf(true));} }
 void createPdf(boolean share){
   final String dir=getCacheDir().getAbsolutePath()+"/propostas"; new File(dir).mkdirs(); pdfFile=new File(dir,"OrcaEletrica_Proposta.pdf");
   PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); PrintDocumentAdapter adapter=web.createPrintDocumentAdapter("OrcaEletrica");
   PrintAttributes attr=new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","pdf",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build();
   adapter.onLayout(null,attr,new CancellationSignal(),new PrintDocumentAdapter.LayoutResultCallback(){public void onLayoutFinished(PrintDocumentInfo info,boolean changed){adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES},ParcelFileDescriptor.open(pdfFile,ParcelFileDescriptor.MODE_CREATE|ParcelFileDescriptor.MODE_TRUNCATE|ParcelFileDescriptor.MODE_READ_WRITE),new CancellationSignal(),new PrintDocumentAdapter.WriteResultCallback(){public void onWriteFinished(PageRange[] pages){if(share) shareFile(); else runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF gerado com sucesso.",Toast.LENGTH_SHORT).show());}});}},null);
 }
 void shareFile(){try{Uri uri=FileProvider.getUriForFile(this,"br.com.orcaeletrica.fileprovider",pdfFile);Intent i=new Intent(Intent.ACTION_SEND);i.setType("application/pdf");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(i,"Compartilhar proposta em PDF"));}catch(Exception e){Toast.makeText(this,"Não foi possível compartilhar o PDF.",Toast.LENGTH_LONG).show();}}
}
